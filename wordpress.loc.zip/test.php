﻿<pre>
<?php
/*
$simpleXml = simplexml_load_string('<pmxi_records><node>
		<category><![CDATA[Автоматика>Контроль, управление и питание>Блоки питания>Однофазные блоки питания]]></category>
		<product><![CDATA[[:ru]Блок птания однофазный 6EP1233-1AA00[:en]The power supply single phase 6EP1233-1AA00]]></product>
		<brand><![CDATA[Siemens]]></brand>
		<articles><![CDATA[6EP1233-1AA00]]></articles>
		<pdf><![CDATA[6EP1_233-1AA00.pdf]]></pdf>
		<photo><![CDATA[]]></photo>
		<description><![CDATA[]]></description>
	</node></pmxi_records>', 'SimpleXMLElement', LIBXML_NOCDATA);
	$rootNodes = $simpleXml->xpath('/pmxi_records/node');
	
$qwe = $rootNodes[0]->xpath('./*[not(self::category or self::articles or self::pdf or self::photo or self::description)]/text()[normalize-space()]');

	if(!empty($qwe))
	foreach($qwe as $key=>$val){
		
		print_r($val->getName().'-'.$val[0]."\r\n");
	}

*/


	
?>