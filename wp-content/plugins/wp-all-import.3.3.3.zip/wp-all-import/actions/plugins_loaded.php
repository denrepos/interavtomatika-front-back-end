<?php 

function pmxi_plugins_loaded() {
		

}